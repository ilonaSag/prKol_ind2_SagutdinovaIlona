using System.Windows.Forms;

namespace prKol_ind2_v8_Sagutdinova
{
    public partial class Form1 : Form
    {
        int position;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string formula = textBox1.Text;
            if (formula == "")
            {
                MessageBox.Show("������� �������");
            }
            position = 0;
            //int rez = Formula(formula);
            //MessageBox.Show($"{rez}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string file = "f2.txt";
            Queue<string> people = new Queue<string>();
            Queue<string> young = new Queue<string>();
            Queue<string> old = new Queue<string>();
            string[] line = File.ReadAllLines(file);
            foreach (string lin in line)
                people.Enqueue(lin);
            while (people.Count > 0)
            {
                string human = people.Dequeue();
                string[] part = human.Split(' ');
                if (part.Length == 6 && int.TryParse(part[4], out int age))
                {
                    if (age < 30)
                        young.Enqueue(human);
                    else
                        old.Enqueue(human);
                }
            }
            listBox1.Items.Clear();
            listBox1.Items.Add("���� ������ 30:");
            Enumerable.Range(0, young.Count)
                .Select(_ => young.Dequeue())
                .ToList()
                .ForEach(item => listBox1.Items.Add(item));
            listBox1.Items.Add("\n���������");
            Enumerable.Range(0, old.Count)
                .Select(_ => old.Dequeue())
                .ToList()
                .ForEach(item => listBox1.Items.Add(item));
        }
        //public int Formula(string formula)
        //{
            
        //}
    }
}